//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� ClientFiveChess.rc ʹ��
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CLIENTFIVECHESS_DIALOG      102
#define IDD_SRVINFO_DIALOG              103
#define IDD_RIGHTPANEL_DIALOG           104
#define IDD_LEFTPANEL_DIALOG            105
#define IDD_CHESSBORAD_DIALOG           106
#define IDI_MAINICON                    127
#define IDR_MAINFRAME                   128
#define IDB_CHESSBOARD                  130
#define IDB_WHITE                       131
#define IDB_BLACK                       132
#define IDB_PLAYER                      133
#define IDB_BLANK                       134
#define IDB_BKBUTTON                    135
#define IDC_BEGIN                       1000
#define IDC_SVRIP                       1001
#define IDC_PORT                        1002
#define IDC_NICKNAME                    1003
#define IDC_LIST1                       1005
#define IDC_LIST2                       1006
#define IDC_USERLIST                    1006
#define IDC_RICHEDIT1                   1007
#define IDC_CONVERSATION                1007
#define IDC_EDIT1                       1008
#define IDC_BUTTON1                     1009
#define IDC_BT_BACK                     1009
#define IDC_PANEL1                      1010
#define IDC_DRAW_CHESS                  1010
#define IDC_PANEL2                      1011
#define IDC_BEGINGAME                   1011
#define IDC_PANEL3                      1012
#define IDC_GIVE_UP                     1012
#define IDC_BUTTON5                     1013
#define IDC_USER                        1013
#define IDC_BACK_PLAY                   1013
#define IDC_SENDMSG                     1014
#define IDC_NETSTATE                    1015
#define IDC_MESSAGE                     1016
#define IDC_NETSTATE2                   1017
#define IDC_TOP                         1018
#define IDC_BOTTOM                      1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
