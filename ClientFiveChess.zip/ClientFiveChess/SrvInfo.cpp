// SrvInfo.cpp : implementation file
//

#include "stdafx.h"
#include "ClientFiveChess.h"
#include "SrvInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSrvInfo dialog

CSrvInfo::CSrvInfo(CWnd *pParent /*=NULL*/)
    : CDialog(CSrvInfo::IDD, pParent)
{
    m_strNickName = _T("");

    //��ȡ��������
    char host[MAX_PATH];
    gethostname(host, MAX_PATH);
    CString m_HostName = host;
    hostent *phost = gethostbyname(host);
    if(phost) {
        char *pIP = inet_ntoa(*(in_addr *)phost->h_addr_list[0]);
        m_strServerIp = pIP;
    }
    // �˿ں�
    m_nServerPort = 9527;
}

void CSrvInfo::DoDataExchange(CDataExchange *pDX)
{
    CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CSrvInfo)
    DDX_Text(pDX, IDC_PORT, m_nServerPort);
    DDV_MinMaxUInt(pDX, m_nServerPort, 0, 10000);
    DDX_Text(pDX, IDC_SVRIP, m_strServerIp);
    DDX_Text(pDX, IDC_NICKNAME, m_strNickName);
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSrvInfo, CDialog)
    //{{AFX_MSG_MAP(CSrvInfo)
    //}}AFX_MSG_MAP
    ON_BN_CLICKED(IDOK, &CSrvInfo::OnBnClickedOk)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSrvInfo message handlers
void CSrvInfo::OnOK()
{
    UpdateData();
    CDialog::OnOK();
}


void CSrvInfo::OnBnClickedOk()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    CDialog::OnOK();
}


BOOL CSrvInfo::OnInitDialog()
{
    CDialog::OnInitDialog();

    return TRUE;  // return TRUE unless you set the focus to a control
    // �쳣: OCX ����ҳӦ���� FALSE
}
